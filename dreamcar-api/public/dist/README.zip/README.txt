We can connect on sk p, and reduce cost.
live:.cid.350c141d28ed3850