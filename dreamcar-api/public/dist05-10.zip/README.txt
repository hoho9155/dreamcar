You may copy only assets folder to public directory.

If you hope, we can connect in sk for more detail.
live:.cid.350c141d28ed3850